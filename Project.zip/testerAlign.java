public class testerAlign {

	public static void main(String[] args) {
		Alignable s = new Alignable();
		Alignable.align("aatcg","aaootcg");

	}

}